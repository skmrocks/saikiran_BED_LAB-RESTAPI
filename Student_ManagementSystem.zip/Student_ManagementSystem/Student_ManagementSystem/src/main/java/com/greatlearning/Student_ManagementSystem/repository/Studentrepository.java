package com.greatlearning.Student_ManagementSystem.repository;

import java.util.List;

import com.greatlearning.Student_ManagementSystem.entity.Student;

public interface Studentrepository {

	List<Student> findAll();

	void save(Student theStudent);

	void deleteById(int id);

	Object findById(int id);

}
