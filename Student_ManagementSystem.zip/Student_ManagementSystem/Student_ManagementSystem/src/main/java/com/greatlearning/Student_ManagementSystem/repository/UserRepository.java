package com.greatlearning.Student_ManagementSystem.repository;

public class UserRepository {

}
