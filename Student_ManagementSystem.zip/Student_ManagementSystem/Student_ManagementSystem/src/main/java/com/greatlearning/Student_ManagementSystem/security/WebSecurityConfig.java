package com.greatlearning.Student_ManagementSystem.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.greatlearning.Student_ManagementSystem.service.UserDetailsServiceimpl;


@Configuration
public class WebSecurityConfig extends WebSecurityConfiguration {

	@Bean
	public UserDetailsServiceimpl userDetailsService() {
		return new UserDetailsServiceimpl();
	}
	
	@Bean
	public BCryptPasswordEncoder PasswordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userDetailsService());
		authProvider.setPasswordEncoder(PasswordEncoder());
		
		return authProvider;
	}
	
	protected void configure(AuthenticationManagerBuilder auth)throws Exception{
		auth.authenticationProvider(authenticationProvider());
	}
	 
	@Override
	protected void configure(HttpSecurity http) throws Exception{
		http.authorizeRequests()
		.antMatchers("/","/student/save","/student/showFormForAdd","/stident/403").hasAnyAuthority("USER","ADMIN")
		.antMatchers("/student/showFormForUpdate","/student/delete").hasAuthority("ADMIN")
		.anyRequest().authenticated()
		.and()
		.formLogin().loginProcessingUrl("/login").successForwardUrl("/student/list").permitALL()
		.and()
		.logout().logoutSuccessUrl("/login").permitALL()
		.and()
		.excetionHandling().accessDeniedPage("/student/403")
		.and()
		.cors().and().csrf().disable();
	}
}
