package com.greatlearning.Student_ManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.greatlearning.Student_ManagementSystem.entity.Student;
import com.greatlearning.Student_ManagementSystem.repository.Studentrepository;

import jakarta.transaction.Transactional;

@Repository
public class StudentServiceimpl implements StudentService {

	@Autowired
	Studentrepository studentRepository;
	
	@Transactional
	public List<Student> findAll(){
		List<Student> students = studentRepository.findAll();
		
		return students;
	}
	@Transactional
	public Student findById(int id) {
		Student student = new Student();
		
		//find record with Id form the database table
		student = studentRepository.findById(id).get();
		
		return student;
	}
	
	@Transactional
	public void save(Student theStudent) {
		studentRepository.save(theStudent);
	}
	@Transactional 
	public void deleteById(int id) {
		studentRepository.deleteById(id);
	}
	
}
